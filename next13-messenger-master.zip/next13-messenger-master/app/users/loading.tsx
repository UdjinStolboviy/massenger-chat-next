import LoadingModal from "../components/modals/LoadingModal";

const Loading = () => {
  return ( 
    <LoadingModal />
  );
}
 
export default Loading;